triangulation
=============

Ear Clipping Triangulation

Program written in Python that implements an ear-clipping algorithm for simple polygons.
The UI is written with pygame.

The triangulation algorithm itself is contained in triangulation.py, everything else is rather irrelevant.